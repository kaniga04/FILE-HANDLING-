import java.io.*;
import java.util.Scanner;

public class FileOperations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String filePath = "C:/Users/kanig/Pictures/Saved Pictures/OneDrive/Desktop/demo.java/data1.txt"; // Specify the file path here

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Read file");
            System.out.println("2. Write to file");
            System.out.println("3. Modify file");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1: // Read file
                    readFile(filePath);
                    break;
                case 2: // Write to file
                    System.out.println("Enter text to write to the file:");
                    String content = scanner.nextLine();
                    writeFile(filePath, content);
                    break;
                case 3: // Modify file
                    System.out.println("Enter the word to replace:");
                    String oldWord = scanner.nextLine();
                    System.out.println("Enter the new word:");
                    String newWord = scanner.nextLine();
                    modifyFile(filePath, oldWord, newWord);
                    break;
                case 4: // Exit
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    /**
     * Reads and displays the content of the specified file.
     * @param filePath The path to the file to be read.
     */
    public static void readFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            System.out.println("C:/Users/kanig/Pictures/Saved Pictures/OneDrive/Documents/data1.txt");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }

    /**
     * Writes the specified content to the file. Overwrites existing content.
     * @param filePath The path to the file to be written to.
     * @param content The content to write into the file.
     */
    public static void writeFile(String filePath, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(content);
            System.out.println("File written successfully.");
        } catch (IOException e) {
            System.out.println("Error writing to the file: " + e.getMessage());
        }
    }
/**
     * Modifies the file by replacing all occurrences of a word with a new word.
     * @param filePath The path to the file to be modified.
     * @param oldWord The word to be replaced.
     * @param newWord The word to replace with.
     */
    public static void modifyFile(String filePath, String oldWord, String newWord) {
        File file = new File(filePath);
        StringBuilder content = new StringBuilder();

        // Read file content
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Replace the old word with the new word
                content.append(line.replace(oldWord, newWord)).append(System.lineSeparator());
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
            return;
        }

        // Write modified content back to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(content.toString());
            System.out.println("File modified successfully.");
        } catch (IOException e) {
            System.out.println("Error writing to the file: " + e.getMessage());
        }
    }
}